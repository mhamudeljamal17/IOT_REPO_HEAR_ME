from TTS.api import TTS
import torch
from TTS.tts.configs.xtts_config import XttsConfig, XttsAudioConfig
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.models.xtts import XttsArgs

# allowlist classes
torch.serialization.add_safe_globals([
    XttsConfig,
    XttsAudioConfig,
    BaseDatasetConfig,
    XttsArgs
])

print("hiiiiiiiiiiii Starting model load...")

# initialize TTS model
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2")
print("goooooooodddd Model loaded successfully")

print("attribuutesssss::::::::")
print(dir(tts))


import os

emotions = ["happy", "sad", "angry", "neutral"]
sentences = [
    "I will meet you tomorrow.",
    "This is a very interesting idea.",
    "I think we should talk about this.",
    "I don’t know what to do.",
    "Please help me with this problem."
]

os.makedirs("dataset", exist_ok=True)
print("good")

if tts.is_multi_speaker:
    speakers_dict = tts.synthesizer.tts_model.speaker_manager.speakers
    speaker = list(speakers_dict.keys())[0]  # pick the first speaker
else:
    speaker = None

# Check if the model is multi-lingual
if tts.is_multi_lingual:
    language = tts.synthesizer.tts_model.language_manager.language_names[0]

else:
    language = None

for emotion in emotions:
    os.makedirs(f"dataset/{emotion}", exist_ok=True)
    for i in range(100):
        text = sentences[i % len(sentences)]
        out = f"dataset/{emotion}/{emotion}_{i}.wav"

        tts.tts_to_file(
            text=text,
            file_path=out,
            speaker=speaker if tts.is_multi_speaker else None,
            language=language if tts.is_multi_lingual else None,
            emotion=emotion
        )
        print("Generated:", out)
