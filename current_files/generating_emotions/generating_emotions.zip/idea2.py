from TTS.api import TTS
import torch
from TTS.tts.configs.xtts_config import XttsConfig, XttsAudioConfig
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.models.xtts import XttsArgs
from pydub import AudioSegment
import os



# allowlist classes
torch.serialization.add_safe_globals([
    XttsConfig,
    XttsAudioConfig,
    BaseDatasetConfig,
    XttsArgs
])

print("Loading XTTS...")

tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2")

print("Model loaded.")

# pick a speaker
if tts.is_multi_speaker:
    speakers_dict = tts.synthesizer.tts_model.speaker_manager.speakers

    speaker = list(speakers_dict.keys())[-8]
else:
    speaker = None

# pick language
if tts.is_multi_lingual:
    language = tts.synthesizer.tts_model.language_manager.language_names[0]

else:
    language = None

sentences = [
    "I need your help right now.",
    "Please answer immediately.",
    "This is important, listen carefully.",
]

# create dataset folders
os.makedirs("dataset/neutral", exist_ok=True)
os.makedirs("dataset/emergency", exist_ok=True)

def make_emergency_voice(path):
    audio = AudioSegment.from_wav(path)

    # Increase speed (urgent)
    audio = audio.speedup(1.05)

    # Increase pitch (panic)
    audio = audio._spawn(audio.raw_data, overrides={
        "frame_rate": int(audio.frame_rate * 1.1)
    }).set_frame_rate(audio.frame_rate)

    # Make louder
    audio = audio + 3

 #optional: slight distortion
    audio = audio.compress_dynamic_range(threshold=-30)

    audio.export(path, format="wav")


# Generate neutral and emergency versions
for i in range(10):
    text = sentences[i % len(sentences)]

    # Neutral
    out_neutral = f"datasetmale/neutral/neutral_{i}.wav"
    tts.tts_to_file(text=text, file_path=out_neutral,
                    speaker=speaker, language=language, emotion="neutral")
    print("Generated:", out_neutral)

    # Emergency (base TTS)
    out_emergency = f"datasetmale/emergency/trial2_emergency_with_compression{i}.wav"
    tts.tts_to_file(text=text, file_path=out_emergency,
                    speaker=speaker, language=language, emotion="angry")

    # Apply post-processing to make it extreme
    make_emergency_voice(out_emergency)

    print("Generated EMERGENCY:", out_emergency)

print("DONE 🎉")
